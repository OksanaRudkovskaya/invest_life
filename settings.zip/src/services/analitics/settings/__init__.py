EXPECTED_TOKEN = '12345'
VERIFY_TOKEN_MIDDLEWARE = False

SCALERS_PATH = "./model/scalers_lstm_mini.pkl"
MODEL_PATH = r"./model/lstm_model_mini_with_config.pth"